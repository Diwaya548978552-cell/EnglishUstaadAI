package com.englishustaad.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var heardText: TextView
    private lateinit var chatContainer: LinearLayout
    private lateinit var micButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        heardText = findViewById(R.id.heardText)
        chatContainer = findViewById(R.id.chatContainer)
        micButton = findViewById(R.id.micButton)

        tts = TextToSpeech(this, this)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is not available on this phone."
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                status.text = "Listening… speak naturally."
                micButton.text = "🎙️ Listening…"
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                micButton.text = "🎤 Speak English"
                status.text = "Thinking…"
            }
            override fun onError(error: Int) {
                micButton.text = "🎤 Speak English"
                status.text = "I couldn't hear that. Please try again."
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) handleUserSpeech(text)
                micButton.text = "🎤 Speak English"
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) heardText.text = text
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        micButton.setOnClickListener { startListening() }

        addTeacherMessage(
            "Hello! I am English Ustaad. Speak to me in English. " +
            "I will correct your sentence and explain the mistake in Urdu."
        )
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        heardText.text = "Listening…"
        speechRecognizer.startListening(intent)
    }

    private fun handleUserSpeech(text: String) {
        heardText.text = text
        addUserMessage(text)

        // Temporary local teacher engine for the first build.
        // Next version will replace this with an on-device LLM (llama.cpp/llama Kotlin)
        // that performs real grammar correction and Urdu explanations.
        val reply = basicTeacherReply(text)
        addTeacherMessage(reply)
        speak(reply)
        status.text = "Your turn — press the microphone."
    }

    private fun basicTeacherReply(text: String): String {
        val lower = text.lowercase(Locale.US)
        return when {
            lower.contains("i am go") ->
                "Correction: “I am going to the market.”\n\nUrdu: “I am go” ghalat hai. Present continuous mein “am + going” use hota hai.\n\nNow say: “I am going to the market.”"
            lower.contains("yesterday") && lower.contains("go") ->
                "Correction: Use “went” for the past.\n\nUrdu: “Yesterday” past time hai, is liye “go” ki jagah “went” use hoga.\n\nExample: “Yesterday, I went to the market.”"
            else ->
                "Good! I understood you. In the full AI version, I will check your grammar, correct your sentence, explain the mistake in Urdu, and continue the conversation.\n\nNow ask me a question in English."
        }
    }

    private fun addUserMessage(text: String) {
        val tv = TextView(this).apply {
            this.text = "You: $text"
            textSize = 17f
            setTextColor(0xFF111827.toInt())
            setPadding(12, 14, 12, 14)
        }
        chatContainer.addView(tv)
    }

    private fun addTeacherMessage(text: String) {
        val tv = TextView(this).apply {
            this.text = "English Ustaad: $text"
            textSize = 17f
            setTextColor(0xFF1D4ED8.toInt())
            setPadding(12, 14, 12, 14)
        }
        chatContainer.addView(tv)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "teacher")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            status.text = "Microphone permission is required for voice lessons."
        }
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
