# English Ustaad AI

A starter Android project for a voice-first English learning assistant.

## Current build
- Android native Kotlin
- Microphone speech input
- Live partial speech display
- Text-to-speech teacher replies
- Urdu grammar explanation examples
- Simple conversation UI

## Important
This first project is deliberately dependency-light so it is easy to open in Android Studio.

The real unlimited/offline AI teacher still needs an on-device LLM integration. The next stage is to add a small quantized GGUF model through llama.cpp (or an equivalent Android runtime), then replace `basicTeacherReply()` with the model's inference engine.

## Open
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect the Redmi Note 15 5G or use an emulator.
4. Run the `app` configuration.
5. Allow microphone permission.
6. Press "Speak English".

## Target
The intended final app:
Voice -> speech recognition -> local English-teacher LLM -> Urdu correction -> natural voice reply.
